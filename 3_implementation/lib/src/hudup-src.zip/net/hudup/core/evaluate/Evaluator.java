package net.hudup.core.evaluate;

import java.util.EventListener;
import java.util.List;

import javax.swing.event.EventListenerList;

import net.hudup.core.PluginStorage;
import net.hudup.core.RegisterTable;
import net.hudup.core.RegisterTable.AlgFilter;
import net.hudup.core.alg.Alg;
import net.hudup.core.alg.SetupAlgEvent;
import net.hudup.core.alg.SetupAlgListener;
import net.hudup.core.alg.TestingAlg;
import net.hudup.core.data.DataConfig;
import net.hudup.core.data.Dataset;
import net.hudup.core.data.DatasetPair;
import net.hudup.core.data.DatasetPool;
import net.hudup.core.data.Fetcher;
import net.hudup.core.data.Profile;
import net.hudup.core.evaluate.EvaluatorEvent.Type;
import net.hudup.core.logistic.AbstractRunner;
import net.hudup.core.logistic.SystemUtil;
import net.hudup.core.logistic.xURI;
import net.hudup.core.logistic.ui.ProgressEvent;
import net.hudup.core.logistic.ui.ProgressListener;


/**
 * {@link Evaluator} is one of main classes of Hudup framework, which is responsible for executing and evaluation algorithms according to built-in and user-defined metrics.
 * Such metrics implement by {@code Metric} interface. As an evaluator of any recommendation algorithm, {@code Evaluator} is the bridge between {@code Dataset} and {@code Recommender} and it has six roles:
 * <ol>
 * <li>
 * It is a loader which loads and configures {@code Dataset}.
 * </li>
 * <li>
 * It is an executor which calls methods {@code Recommender#estimate(...)} and {@code Recommender#recommend(...)}.
 * </li>
 * <li>
 * It is an analyzer which analyzes and translates the result of algorithm execution into the form of evaluation metrics. The execution result is output of method {@code Recommender#estimate(...)} or {@code Recommender#recommend(...)}.
 * Evaluation metric is represented by {@code Metric} interface. {@code Metrics} class manages a list of {@code Metric} (s).
 * </li>
 * <li>
 * It is a registry. If external applications require receiving result from {@code Evaluator}, they need to register with it.
 * Such applications must implement {@code EvaluatorListener} interface. In other words, {@code Evaluator} contains a list of {@code EvaluatorListener} (s).
 * </li>
 * <li>
 * Whenever it finishes a call of method {@code Recommender#estimate(...)} or {@code Recommender#recommend(...)}, it issues a so-called evaluation event and send back evaluation metrics to external applications after executing algorithm.
 * So it is also a provider. The evaluation event is wrapped by {@code EvaluatorEvent} class.
 * </li>
 * <li>
 * It works as a service which allows scientists to start, pause, resume, and stop the evaluation process via its methods {@code start()}, {@code pause()}, {@code resume()}, and {@code stop()}, respectively.
 * </li>
 * </ol>
 * {@code Evaluator} has four most important methods:
 * <ol>
 * <li>
 * Method {@code evaluate(...)} performs main tasks of {@code Evaluator}, which loads {@code Dataset} and activates method {@code Recommender#estimate(...)} or {@code Recommender#recommend(...)} on such {@code Dataset}.
 * </li>
 * <li>
 * Method {@code analyze(...)} is responsible for analyzing the result returned by method {@code Recommender#estimate(...)} or {@code Recommender#recommend(...)} so as to translate such result into evaluation metric.
 * Metrics are used to assess algorithms and they are discussed later. By default implementation, {@code analyze(...)} method will simply call {@code Metric#recalc(...)} method in order to calculate such metric itself.
 * </li>
 * <li>
 * Method {@code issue(...)} issues an evaluation event and sends back evaluation metrics to external applications. Method {@code issue(...)} is also named {@code fireEvaluatorEvent(...)}.
 * </li>
 * </ol>
 * If external applications want to receive metrics, they need to register with {@code Evaluator} by calling {@code Evaluator#addListener(...)} method. The evaluation process has five steps:
 * <ol>
 * <li>
 * {@code Evaluator} calls {@code Evaluator#evaluate(...)} method to load and feed {@code Dataset} to {@code Recommender}.
 * </li>
 * <li>
 * Method {@code Recommender#estimate(...)} or {@code Recommender#recommend(...)} is executed by {@code Evaluator#evaluate(...)} method to perform recommendation task.
 * </li>
 * <li>
 * Method {@code Evaluator#analyze(...)} analyzes the result returned by method {@code Recommender#estimate(...)} or {@code Recommender#recommend(...)} and translates such result into {@code Metric}.
 * The {@code Metrics} class manages a list of {@code Metric} (s).
 * </li>
 * <li>
 * External applications that implement {@code EvaluatorListener} interface register with {@code Evaluator} by calling {@code Evaluator#addListener(...)} method.
 * </li>
 * <li>
 * Method {@code Evaluator#issue(...)} sends {@code Metrics} to external applications.
 * </li>
 * </ol>
 * 
 * It is associated with a friendly user interface in order to give facilities to users.
 * 
 * @author Loc Nguyen
 * @version 10.0
 *
 */
public abstract class Evaluator extends AbstractRunner implements SetupAlgListener {

	
	/**
	 * Configuration of this evaluator.
	 */
	protected EvaluatorConfig config = null;

	
	/**
	 * Holding a list of {@link EventListener} (s)
	 * 
	 */
    protected EventListenerList listenerList = new EventListenerList();

    
    /**
     * List of algorithms that are evaluated by this evaluator.
     */
    protected List<Alg> algList = null;
    
    
    /**
     * This {@code dataset pool} contains many training and testing datasets, which is fed to evaluator, which allows evaluator assesses algorithm on many testing datasets.
     */
    protected DatasetPool pool = null;
    
    
    /**
     * Additional parameter for this evaluator.
     */
    protected Object parameter = null;
    
    
	/**
     * The list of metrics resulted from the evaluation process.
     */
	protected volatile Metrics result = null;
	
	
    /**
     * The list of original metrics used to evaluate algorithms in {@link #algList}.
     */
	protected NoneWrapperMetricList metricList = null;

	
    /**
	 * Default constructor.
	 */
	public Evaluator() {
		this.config = new EvaluatorConfig(xURI.create(EvaluatorConfig.evalConfig));
		metricList = defaultMetrics();
		metricList.sort();
	}
	
	
	/**
	 * Starting the evaluation process on specified algorithms with specified dataset pool.
	 * The original (built-in) metrics were discovered by Plug-in manager.
	 * 
	 * @param algList specified list of algorithms.
	 * @param pool specified dataset pool containing many training datasets and testing datasets.
	 * @param parameter additional parameter.
	 */
	public synchronized void evaluate(List<Alg> algList, DatasetPool pool, Object parameter) {
		if (isStarted() || this.algList != null || this.pool != null) {
			logger.error("Evaluator is running and so evaluation is not run");
			return;
		}
		
		this.algList = algList;
		this.pool = pool;
		this.parameter = parameter;
		this.result = null;
		start();
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			run0();
		}
		catch (Throwable e) {
			e.printStackTrace();
		}
	}

	
	/**
	 * Actually, make evaluation process on algorithms with a dataset pool according to original (built-in) metrics.
	 */
	protected void run0() {
		int progressStep = 0;
		int progressTotal = 0;
		for (int i = 0; i < pool.size(); i++) {
			Dataset testing = pool.get(i).getTesting();
			Fetcher<Profile> fetcher = fetchTesting(testing);
			try {
				progressTotal += fetcher.getMetadata().getSize();
				fetcher.close();
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		progressTotal *= algList.size();
		
		result = new Metrics();
		
		Thread current = Thread.currentThread();
		for (int i = 0; current == thread && algList != null && i < algList.size(); i++) {
			Alg alg = algList.get(i);
			
			for (int j = 0; current == thread && pool != null && j < pool.size(); j++) {
				
				Fetcher<Profile> testingFetcher = null;
				try {
					DatasetPair dsPair = pool.get(j);
					Dataset     training = dsPair.getTraining();
					Dataset     testing = dsPair.getTesting();
					int         datasetId = j + 1;
					xURI        datasetUri = testing.getConfig().getUriId();
					
					// Adding default metrics to metric result
					result.add( alg.getName(), datasetId, datasetUri, ((NoneWrapperMetricList)metricList.clone()).sort().list() );
					
					if (alg instanceof TestingAlg)
						((TestingAlg)alg).addSetupListener(this);
					
					long beginSetupTime = System.currentTimeMillis();
					//
					setupAlg(alg, training);
					//
					long endSetupTime = System.currentTimeMillis();
					long setupElapsed = endSetupTime - beginSetupTime;
					Metrics setupMetrics = result.recalc(
							alg, 
							datasetId, 
							SetupTimeMetric.class, 
							new Object[] { setupElapsed / 1000.0f }
						); // calculating setup time metric
					fireEvaluatorEvent(new EvaluatorEvent(this, Type.doing, setupMetrics)); // firing setup time metric
					
					if (alg instanceof TestingAlg)
						((TestingAlg)alg).removeSetupListener(this);

					
					testingFetcher = fetchTesting(testing);
					int vCurrentTotal = testingFetcher.getMetadata().getSize();
					int vCurrentCount = 0;
					int vExecutedCount = 0;
					while (testingFetcher.next() && current == thread) {
						progressStep++;
						vCurrentCount++;
						EvaluatorProgressEvent progressEvt = new EvaluatorProgressEvent(this, progressTotal, progressStep);
						progressEvt.setAlgName(alg.getName());
						progressEvt.setDatasetId(datasetId);
						progressEvt.setCurrentCount(vCurrentCount);
						progressEvt.setCurrentTotal(vCurrentTotal);
						fireProgressEvent(progressEvt);
						
						Profile testingProfile = testingFetcher.pick();
						if (testingProfile == null)
							continue;
						
						Profile param = prepareExecuteAlg(alg, testingProfile);
						//
						long beginRecommendTime = System.currentTimeMillis();
						Object executedResult = executeAlg(alg, param);
						long endRecommendTime = System.currentTimeMillis();
						//
						long recommendElapsed = endRecommendTime - beginRecommendTime;
						Metrics speedMetrics = result.recalc(
								alg, 
								datasetId, 
								SpeedMetric.class, 
								new Object[] { recommendElapsed / 1000.0f }
							); // calculating time speed metric
						fireEvaluatorEvent(new EvaluatorEvent(
								this, 
								Type.doing, 
								speedMetrics)); // firing time speed metric
						
						if (executedResult != null) { // successful recommendation
							Metrics executedMetrics = result.recalc(
									alg, 
									datasetId,
									new Object[] { executedResult, extractTestValue(alg, testingProfile) }
								); // calculating execution metric
							
							vExecutedCount++;
							
							fireEvaluatorEvent(new EvaluatorEvent(
									this, 
									Type.doing, 
									executedMetrics, 
									executedResult, 
									extractTestValue(alg, testingProfile))); // firing execution metric
						}
						
						
						synchronized (this) {
							while (paused) {
								notifyAll();
								wait();
							}
						}
						
					} // User id iterate
					
					Metrics hudupRecallMetrics = result.recalc(
							alg, 
							datasetId, 
							HudupRecallMetric.class, 
							new Object[] { new FractionMetricValue(vExecutedCount, vCurrentTotal) }
						);
					fireEvaluatorEvent(new EvaluatorEvent(this, Type.doing, hudupRecallMetrics));
					
					Metrics doneOneMetrics = result.gets(alg.getName(), datasetId);
					fireEvaluatorEvent(new EvaluatorEvent(this, Type.done_one, doneOneMetrics));
					
				} // end try
				catch (Throwable e) {
					e.printStackTrace();
				}
				finally {
					try {
						if (testingFetcher != null)
							testingFetcher.close();
					} 
					catch (Throwable e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					unsetupAlg(alg);
				}
				
				SystemUtil.enhanceAuto();

			} // dataset iterate
			
		} // algorithm iterate
		
		
		synchronized (this) {
			thread = null;
			paused = false;
			clear();

			fireEvaluatorEvent(new EvaluatorEvent(this, Type.done, result));

			notifyAll();
		}
		
	}
	
	
	/**
	 * Setting up specified algorithm based on training dataset and additional parameters.
	 * @param alg specified algorithm.
	 * @param training training dataset.
	 */
	protected abstract void setupAlg(Alg alg, Dataset training);
	
	
	/**
	 * Unsetting up specified algorithm based on training dataset and additional parameters.
	 * @param alg specified algorithm.
	 */
	protected abstract void unsetupAlg(Alg alg);
	
	
	/**
	 * Fetching profiles from the specified testing dataset.
	 * @param testing specified training dataset.
	 * @return fetcher for retrieving profiles from the specified testing dataset as {@link Fetcher}.
	 */
	protected abstract Fetcher<Profile> fetchTesting(Dataset testing);
	
	
	/**
	 * Prepare to execute the specified algorithm.
	 * @param alg specified algorithm.
	 * @param testingProfile testing profile as coarse parameter.
	 * @return a returned profile as refined parameter for algorithm execution.
	 */
	protected abstract Profile prepareExecuteAlg(Alg alg, Profile testingProfile);
	
	
	/**
	 * Execute the specified algorithm.
	 * @param alg specified algorithm.
	 * @param param specified profile as parameter for algorithm execution.
	 * @return an object as result of algorithm execution.
	 */
	protected abstract Object executeAlg(Alg alg, Profile param);
	
	
	/**
	 * Extracting value from testing profile.
	 * @param alg specified algorithm.
	 * @param testingProfile testing profile.
	 * @return value from testing profile.
	 */
	protected abstract Object extractTestValue(Alg alg, Profile testingProfile);
	
	
	@Override
	public void receivedSetup(SetupAlgEvent evt) {
		// TODO Auto-generated method stub
		fireSetupAlgEvent(evt);
	}
	
	
	/**
	 * Defining the list of default metrics.
	 * @return the list of default metrics as {@link NoneWrapperMetricList}.
	 */
	public abstract NoneWrapperMetricList defaultMetrics();
	
	
	/**
	 * Checking whether the specified algorithm is accepted by this evaluator.
	 * @param alg specified algorithm.
	 * @return whether the specified algorithm is accepted by this evaluator.
	 */
	public abstract boolean acceptAlg(Alg alg);
	
	
	/**
	 * Returning name of this evaluator.
	 * @return name of this evaluator.
	 */
	public abstract String getName();
	
	
	/**
	 * Getting main data unit for evaluation such as rating matrix, sample.
	 * @return main data unit for evaluation such as rating matrix, sample.
	 */
	public String getMainUnit() {
		return DataConfig.RATING_UNIT;
	}
	
	
	/**
	 * Getting result of evaluation process as list of metrics.
	 * @return result of evaluation process as {@link Metrics}.
	 */
	public Metrics getResult() {
		return result;
	}

	
	/**
	 * Setting metric list.
	 * @param metricList specified metric list.
	 */
	public synchronized void setMetricList(List<Metric> metricList) {
		if (isStarted()) {
			logger.error("Evaluator is started and so it is impossible to set up metric list");
			return;
		}
		
		this.metricList.clear();
		this.metricList.addAll(metricList);
		this.metricList.sort();
	}
	
	
	/**
	 * Getting the list of metrics resulted from the evaluation process.
	 * @return list of metrics resulted from the evaluation process.
	 */
	public List<Metric> getMetricList() {
		return this.metricList.list();
	}
	
	
	/**
	 * Extracting algorithms from plug-in storage.
	 * @return register table to store algorithms extracted from plug-in storage.
	 */
	public RegisterTable extractAlgFromPluginStorage() {
		List<Alg> algList = PluginStorage.getNormalAlgReg().getAlgList(new AlgFilter() {
			
			@Override
			public boolean accept(Alg alg) {
				// TODO Auto-generated method stub
				return acceptAlg(alg);
			}
		});
		
		return new RegisterTable(algList);
	}
	
	
	@Override
	protected void clear() {
		// TODO Auto-generated method stub
		this.algList = null;
		this.pool = null;
		this.parameter = null;
	}

	
	@Override
	public void task() {
		// TODO Auto-generated method stub
		logger.info("Evaluator#task not used because overriding Evaluator#run");
	}

	
	@SuppressWarnings("static-access")
	@Override
	public synchronized void forceStop() {
		super.forceStop();
		
		try {
			Thread.currentThread().sleep(1000);
		} 
		catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		fireEvaluatorEvent(new EvaluatorEvent(this, Type.done, result));
	}
	
	
	/**
	 * Getting configuration of this evaluator.
	 * @return configuration of this evaluator.
	 */
	public EvaluatorConfig getConfig() {
		return config;
	}
	
	
	/**
	 * Add the specified listener to the end of listener list.
	 * 
	 * @param listener specified {@link EvaluatorListener}
	 * 
	 */
	public void addEvaluatorListener(EvaluatorListener listener) {
		synchronized (listenerList) {
			listenerList.add(EvaluatorListener.class, listener);
		}
    }

    
	/**
	 * Remove the specified listener from the listener list.
	 * @param listener specified {@link EvaluatorListener}.
	 */
    public void removeEvaluatorListener(EvaluatorListener listener) {
		synchronized (listenerList) {
			listenerList.remove(EvaluatorListener.class, listener);
		}
    }
	
    
    /**
     * Return a {@link EvaluatorListener} list for this evaluator.
     * 
     * @return array of {@link EvaluatorListener} for this evaluator.
     * 
     */
    protected EvaluatorListener[] getEvaluatorListeners() {
		synchronized (listenerList) {
			return listenerList.getListeners(EvaluatorListener.class);
		}
    }

    
    /**
     * Firing (issuing) an event from this evaluator to all listeners. 
     * 
     * @param evt event from this evaluator.
     */
    protected void fireEvaluatorEvent(EvaluatorEvent evt) {
    	
		EvaluatorListener[] listeners = getEvaluatorListeners();
		
		for (EvaluatorListener listener : listeners) {
			try {
				listener.receivedEvaluation(evt);
			}
			catch (Throwable e) {
				e.printStackTrace();
			}
		}
	
    }

    
    /**
     * Adding the specified progress listener.
     * @param listener specified progress listener.
     */
	public void addProgressListener(EvaluatorProgressListener listener) {
		synchronized (listenerList) {
			listenerList.add(EvaluatorProgressListener.class, listener);
		}
    }

    
	/**
     * Removing the specified progress listener.
	 * @param listener specified progress listener.
	 */
    public void removeProgressListener(EvaluatorProgressListener listener) {
		synchronized (listenerList) {
			listenerList.remove(EvaluatorProgressListener.class, listener);
		}
    }
	
    
    /**
     * Getting an array of evaluation progress listener.
     * @return array of {@link ProgressListener} (s).
     */
    protected EvaluatorProgressListener[] getProgressListeners() {
		synchronized (listenerList) {
			return listenerList.getListeners(EvaluatorProgressListener.class);
		}
    }
    
    
    /**
     * Firing {@link ProgressEvent}.
     * @param evt the specified for evaluation progress.
     */
    protected void fireProgressEvent(EvaluatorProgressEvent evt) {
    	if (!isStarted())
    		return;

    	EvaluatorProgressListener[] listeners = getProgressListeners();
		
		for (EvaluatorProgressListener listener : listeners) {
			try {
				listener.receivedProgress(evt);
			}
			catch (Throwable e) {
				e.printStackTrace();
			}
		}
	
    }


    /**
     * Adding the specified setup algorithm listener.
     * @param listener specified setup algorithm listener.
     */
	public void addSetupAlgListener(SetupAlgListener listener) {
		synchronized (listenerList) {
			listenerList.add(SetupAlgListener.class, listener);
		}
    }

    
	/**
     * Removing the specified setup algorithm listener.
	 * @param listener specified progress algorithm listener.
	 */
    public void removeSetupAlgListener(SetupAlgListener listener) {
		synchronized (listenerList) {
			listenerList.remove(SetupAlgListener.class, listener);
		}
    }
	
    
    /**
     * Getting an array of setup algorithm listeners.
     * @return array of setup algorithm listeners.
     */
    protected SetupAlgListener[] getSetupAlgListeners() {
		synchronized (listenerList) {
			return listenerList.getListeners(SetupAlgListener.class);
		}
    }
    
    
    /**
     * Firing setup algorithm event.
     * @param evt the specified for setup algorithm event.
     */
    protected void fireSetupAlgEvent(SetupAlgEvent evt) {
    	if (!isStarted())
    		return;

    	SetupAlgListener[] listeners = getSetupAlgListeners();
		
		for (SetupAlgListener listener : listeners) {
			try {
				listener.receivedSetup(evt);
			}
			catch (Throwable e) {
				e.printStackTrace();
			}
		}
	
    }

    
    @Override
	public String toString() {
		// TODO Auto-generated method stub
		return getName();
	}

    
}
